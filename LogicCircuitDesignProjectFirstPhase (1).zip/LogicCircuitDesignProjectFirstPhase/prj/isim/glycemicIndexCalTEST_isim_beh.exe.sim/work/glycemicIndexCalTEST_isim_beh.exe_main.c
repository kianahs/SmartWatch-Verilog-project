/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;



int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    work_m_00000000004121623026_1017851315_init();
    work_m_00000000003764444884_2902715030_init();
    work_m_00000000002009168988_0711356568_init();
    work_m_00000000001399740421_0144891941_init();
    work_m_00000000001941670867_3141826976_init();
    work_m_00000000002271458222_2913075817_init();
    work_m_00000000004134447467_2073120511_init();


    xsi_register_tops("work_m_00000000002271458222_2913075817");
    xsi_register_tops("work_m_00000000004134447467_2073120511");


    return xsi_run_simulation(argc, argv);

}
